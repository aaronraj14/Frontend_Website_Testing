$(document).scroll(function() {
    var y = $(this).scrollTop();
    if (y > 800) {
      $('.scrolltotop').fadeIn();
    } else {
      $('.scrolltotop').fadeOut();
    }
  });

$("#overlay").show();
$("#overlay-content").show();

setTimeout(function(){    
  $("#overlay").fadeOut();
}, 2000);

window.setTimeout(function(){$("nav").addClass("fixed-top");}, 2000);
